import React, { useMemo, useState } from "react";
import { addDays, subDays, startOfWeek, endOfWeek, eachDayOfInterval, format, isSameDay, isBefore } from "date-fns";
import { Info, Calendar as CalendarIcon, ChevronLeft, ChevronRight, Filter } from "lucide-react";
import { motion } from "framer-motion";

/**
 * SessionHeatmapCalendar
 * ------------------------------------------------------
 * GitHub-style calendar heatmap for trading performance.
 * - Buckets PnL by day with color intensity
 * - Filter by Session (London / New York / Asian) & Setup tags
 * - Shows streaks, best day, and quick stats
 * - Mock data generator included; replace with your API/Supabase data
 *
 * Drop-in usage:
 *   export default function Page() {
 *     return (
 *       <div className="min-h-screen bg-gray-50 p-6">
 *         <div className="mx-auto max-w-6xl">
 *           <SessionHeatmapCalendar />
 *         </div>
 *       </div>
 *     )
 *   }
 */

// --- Types ---
export type Session = "London" | "New York" | "Asian";

export type Trade = {
  id: string;
  date: string; // ISO date like "2025-08-19"
  session: Session;
  setup: string; // e.g., "Ultimate M1 Trend", "Ultimate M1 Range"
  rMultiple: number; // profit in R (e.g., +2.3, -1.0)
};

// --- Mock Data (replace with your data source) ---
const SETUPS = ["M1 Trend", "M1 Range", "Breakout", "Pullback"];
const SESSIONS: Session[] = ["London", "New York", "Asian"];

function randomBetween(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

function generateMockTrades(daysBack = 120): Trade[] {
  const today = new Date();
  const start = subDays(today, daysBack);
  const days = eachDayOfInterval({ start, end: today });
  const all: Trade[] = [];

  for (const d of days) {
    // 60% chance of having trades that day
    if (Math.random() < 0.6) {
      const n = Math.floor(randomBetween(1, 5));
      for (let i = 0; i < n; i++) {
        const session = SESSIONS[Math.floor(Math.random() * SESSIONS.length)];
        const setup = SETUPS[Math.floor(Math.random() * SETUPS.length)];
        // Skew slightly positive but with tails
        const r = Number((randomBetween(-3.5, 4.5) + randomBetween(-1.0, 1.0) * 0.5).toFixed(2));
        all.push({
          id: `${d.toISOString()}-${i}`,
          date: format(d, "yyyy-MM-dd"),
          session,
          setup,
          rMultiple: r,
        });
      }
    }
  }
  return all;
}

// Color buckets for daily net R
function bucketClass(r: number | null) {
  if (r === null) return "bg-gray-200"; // no trades
  if (r <= -3) return "bg-red-900";
  if (r <= -1.5) return "bg-red-700";
  if (r < 0) return "bg-red-500";
  if (r === 0) return "bg-gray-300";
  if (r < 1) return "bg-green-400";
  if (r < 2.5) return "bg-green-600";
  return "bg-green-800";
}

function legend() {
  const steps = [
    { label: "No trades", cls: "bg-gray-200" },
    { label: "-3R", cls: "bg-red-900" },
    { label: "-1.5R", cls: "bg-red-700" },
    { label: "-0.1R", cls: "bg-red-500" },
    { label: "0R", cls: "bg-gray-300" },
    { label: "+0.5R", cls: "bg-green-400" },
    { label: "+1.5R", cls: "bg-green-600" },
    { label: "+2.5R+", cls: "bg-green-800" },
  ];
  return (
    <div className="flex items-center gap-3 text-xs text-gray-600">
      <span className="inline-flex items-center gap-2"><Info className="h-4 w-4"/> Scale:</span>
      {steps.map((s) => (
        <span key={s.label} className="inline-flex items-center gap-1">
          <span className={`h-3 w-3 rounded ${s.cls}`} /> {s.label}
        </span>
      ))}
    </div>
  );
}

function groupTradesByDay(trades: Trade[]) {
  const map = new Map<string, Trade[]>();
  for (const t of trades) {
    if (!map.has(t.date)) map.set(t.date, []);
    map.get(t.date)!.push(t);
  }
  return map;
}

function sumR(trades: Trade[] | undefined): number | null {
  if (!trades || trades.length === 0) return null;
  return Number(trades.reduce((a, b) => a + b.rMultiple, 0).toFixed(2));
}

function useCalendarRange(days = 120) {
  // Align to full weeks for a clean grid
  const today = new Date();
  const start = startOfWeek(subDays(today, days), { weekStartsOn: 1 }); // Monday
  const end = endOfWeek(today, { weekStartsOn: 1 });
  const daysArr = eachDayOfInterval({ start, end });
  return { start, end, daysArr };
}

const ALL_SESSIONS: Session[] = ["London", "New York", "Asian"];

export default function SessionHeatmapCalendar() {
  // Replace mockTrades with your fetched trades
  const mockTrades = useMemo(() => generateMockTrades(150), []);

  // Filters
  const [activeSessions, setActiveSessions] = useState<Session[]>(ALL_SESSIONS);
  const [activeSetups, setActiveSetups] = useState<string[]>([...SETUPS]);
  const [windowDays, setWindowDays] = useState<number>(120);

  const { daysArr } = useCalendarRange(windowDays);

  // Apply filters
  const filteredTrades = useMemo(() => {
    return mockTrades.filter((t) =>
      activeSessions.includes(t.session) && activeSetups.includes(t.setup)
    );
  }, [mockTrades, activeSessions, activeSetups]);

  const byDay = useMemo(() => groupTradesByDay(filteredTrades), [filteredTrades]);

  // Stats
  const { totalR, winRate, bestDay, streaks } = useMemo(() => {
    let wins = 0, losses = 0, total = 0, totalRacc = 0;
    let best: { date: string; r: number } | null = null;

    for (const [date, trades] of byDay) {
      const r = sumR(trades);
      if (r !== null) {
        total++;
        totalRacc += r;
        if (r > 0) wins++; else if (r < 0) losses++;
        if (!best || r > best.r) best = { date, r };
      }
    }

    // Streaks (consecutive green/red days up to today)
    const today = new Date();
    let green = 0, red = 0;
    // Walk backwards up to 30 days
    for (let i = 0; i < 30; i++) {
      const d = subDays(today, i);
      const key = format(d, "yyyy-MM-dd");
      const r = sumR(byDay.get(key));
      if (r === null) break; // stop at a day with no trades
      if (r > 0) { if (red > 0) break; green++; } else if (r < 0) { if (green > 0) break; red++; } else { break; }
    }

    return {
      totalR: Number(totalRacc.toFixed(2)),
      winRate: total ? Math.round((wins / total) * 100) : 0,
      bestDay: best,
      streaks: { green, red },
    };
  }, [byDay]);

  // Helpers to render weeks (columns) x weekdays (rows)
  const weeks: Date[][] = useMemo(() => {
    const cols: Date[][] = [];
    let col: Date[] = [];
    const firstWeekday = 1; // Monday
    for (const d of daysArr) {
      if (col.length === 0) {
        col.push(d);
      } else {
        const prev = col[col.length - 1];
        const nextDay = addDays(prev, 1);
        if (isSameDay(nextDay, d)) {
          col.push(d);
        } else {
          // Shouldn't happen with eachDayOfInterval but keep safe
          cols.push(col);
          col = [d];
        }
      }
      if (col.length === 7) {
        cols.push(col);
        col = [];
      }
    }
    if (col.length) cols.push(col);

    // Ensure each col starts Monday -> Sunday
    return cols.map((c) => {
      const start = startOfWeek(c[0], { weekStartsOn: firstWeekday });
      return eachDayOfInterval({ start, end: addDays(start, 6) });
    });
  }, [daysArr]);

  // UI interactions
  const toggleSession = (s: Session) => {
    setActiveSessions((prev) => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };
  const toggleSetup = (s: string) => {
    setActiveSetups((prev) => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };

  const shiftWindow = (delta: number) => {
    setWindowDays((d) => Math.min(365, Math.max(30, d + delta)));
  };

  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm">
      {/* Header */}
      <div className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className="rounded-xl bg-gray-100 p-2"><CalendarIcon className="h-5 w-5"/></div>
          <div>
            <h2 className="text-lg font-semibold">Session Heatmap Calendar</h2>
            <p className="text-sm text-gray-600">Visualize daily net R and consistency across sessions & setups.</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <button onClick={() => shiftWindow(-30)} className="inline-flex items-center gap-1 rounded-lg border px-2 py-1 hover:bg-gray-50"><ChevronLeft className="h-4 w-4"/> -30d</button>
          <span className="rounded-lg border px-3 py-1 font-medium">Window: {windowDays}d</span>
          <button onClick={() => shiftWindow(+30)} className="inline-flex items-center gap-1 rounded-lg border px-2 py-1 hover:bg-gray-50">+30d <ChevronRight className="h-4 w-4"/></button>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-5 grid gap-3 md:grid-cols-2">
        <div className="rounded-xl border p-3">
          <div className="mb-2 flex items-center gap-2 text-sm font-medium"><Filter className="h-4 w-4"/> Sessions</div>
          <div className="flex flex-wrap gap-2">
            {ALL_SESSIONS.map((s) => (
              <button
                key={s}
                onClick={() => toggleSession(s)}
                className={`rounded-full px-3 py-1 text-sm border ${activeSessions.includes(s) ? "bg-black text-white" : "bg-white hover:bg-gray-50"}`}
              >{s}</button>
            ))}
          </div>
        </div>
        <div className="rounded-xl border p-3">
          <div className="mb-2 flex items-center gap-2 text-sm font-medium"><Filter className="h-4 w-4"/> Setups</div>
          <div className="flex flex-wrap gap-2">
            {SETUPS.map((s) => (
              <button
                key={s}
                onClick={() => toggleSetup(s)}
                className={`rounded-full px-3 py-1 text-sm border ${activeSetups.includes(s) ? "bg-black text-white" : "bg-white hover:bg-gray-50"}`}
              >{s}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-5 grid gap-3 sm:grid-cols-3">
        <StatCard label="Total Net R" value={totalR.toFixed(2)} sub="(filtered)" />
        <StatCard label="Win Rate" value={`${winRate}%`} sub="by day" />
        <StatCard label="Best Day" value={bestDay ? `${bestDay.r.toFixed(2)}R` : "—"} sub={bestDay ? format(new Date(bestDay.date), "dd MMM") : "—"} />
      </div>

      {/* Legend */}
      <div className="mb-4">{legend()}</div>

      {/* Heatmap */}
      <div className="overflow-x-auto">
        <div className="inline-block">
          <div className="grid grid-cols-[auto,1fr] gap-2">
            {/* Weekday labels */}
            <div className="flex flex-col gap-1 text-xs text-gray-500 pt-5">
              {['Mon','Wed','Fri'].map((d) => (
                <div key={d} className="h-4 leading-4">{d}</div>
              ))}
            </div>

            {/* Weeks grid */}
            <div className="flex gap-1">
              {weeks.map((week, wi) => (
                <div key={wi} className="flex flex-col gap-1">
                  {week.map((day, di) => {
                    // Only show labels on Mon/Wed/Fri rows for compactness
                    const weekday = day.getDay(); // 0=Sun
                    const r = sumR(byDay.get(format(day, "yyyy-MM-dd")));
                    const cls = bucketClass(r);
                    const isFuture = isBefore(new Date(), day) && !isSameDay(new Date(), day);
                    return (
                      <Tooltip key={di} content={tooltipFor(day, byDay)}>
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.2, delay: wi * 0.005 }}
                          className={`h-4 w-4 rounded ${isFuture ? "bg-gray-100" : cls} ring-1 ring-black/5`}
                        />
                      </Tooltip>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Streaks */}
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border p-4">
          <h4 className="mb-1 text-sm font-semibold">Streaks</h4>
          <p className="text-sm text-gray-600">Green (winning) streak: <span className="font-medium text-gray-900">{streaks.green} days</span></p>
          <p className="text-sm text-gray-600">Red (losing) streak: <span className="font-medium text-gray-900">{streaks.red} days</span></p>
        </div>
        <div className="rounded-xl border p-4">
          <h4 className="mb-2 text-sm font-semibold">How to read</h4>
          <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
            <li>Darker green = stronger positive net R for that day; darker red = deeper loss.</li>
            <li>Use filters to isolate Sessions (London/NY/Asian) and specific Setups.</li>
            <li>Hover squares to see daily summary and trades.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function tooltipFor(day: Date, byDay: Map<string, Trade[]>) {
  const key = format(day, "yyyy-MM-dd");
  const trades = byDay.get(key) || [];
  if (!trades.length) return `${format(day, "EEE, dd MMM yyyy")}\nNo trades`;
  const r = sumR(trades);
  const lines = trades
    .slice(0, 6)
    .map(t => `${t.session} • ${t.setup} • ${t.rMultiple}R`);
  const more = trades.length > 6 ? `+${trades.length - 6} more…` : "";
  return `${format(day, "EEE, dd MMM yyyy")}\nNet: ${r}R\n${lines.join("\n")}\n${more}`.trim();
}

function StatCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl border p-4">
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-2xl font-semibold">{value}</div>
      {sub && <div className="text-xs text-gray-500">{sub}</div>}
    </div>
  );
}

// Minimal tooltip (no external UI libs)
function Tooltip({ content, children }: { content: string; children: React.ReactNode }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="relative" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      {children}
      {open && (
        <div className="absolute left-1/2 z-10 -translate-x-1/2 -translate-y-2 transform whitespace-pre rounded-md border bg-white p-2 text-xs text-gray-700 shadow-xl">
          {content}
        </div>
      )}
    </div>
  );
}
